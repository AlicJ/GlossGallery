This is a gallery that holds the gloss examples made by students from McMaster who were in CompSci 1JC3 in 2013 fall.
The course is taught by Dr. Anand. The gallery is built upon the request of the professor.

The gloss animations can be downloaded at:
http://hackage.haskell.org/package/mcmaster-gloss-examples-2013


Contributors: Zichen Jiang, Chang Liu

have fun '(^·ω·^ )'

